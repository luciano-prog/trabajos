var nombre = prompt("introduzca su nombre:","");

document.write("<h2>Bienvenido,"+ nombre +"</h2>");